/*===============================================================*/
/*                                                               */
/*                       face_detect.cpp                         */
/*                                                               */
/*     Main host function for the Face Detection application.    */
/*                                                               */
/*===============================================================*/

// standard C/C++ headers
#include "face_detect_sw.h"


// other headers
#include "typedefs.h"

// data
#include "image0_320_240.h"

int main(int argc, char ** argv) 
{
  // for this benchmark, input data is included in array Data
  // these are outputs
  int result_x[RESULT_SIZE];
  int result_y[RESULT_SIZE];
  int result_w[RESULT_SIZE];
  int result_h[RESULT_SIZE];
  int res_size = 0;

  face_detect_sw(Data, result_x, result_y, result_w, result_h, &res_size);

  return 0;
}
