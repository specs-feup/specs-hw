/*===============================================================*/
/*                                                               */
/*                       3d_rendering.cpp                        */
/*                                                               */
/*      Main host function for the 3D Rendering application.     */
/*                                                               */
/*===============================================================*/

#include "rendering_sw.h"
#include "input_data.h"

int main(int argc, char ** argv) 
{
  bit8 output[MAX_X][MAX_Y];
  rendering_sw(triangle_3ds, output);

  return 0;
}
