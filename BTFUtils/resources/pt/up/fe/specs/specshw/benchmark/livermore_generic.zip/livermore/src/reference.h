
#ifndef _reference_H_
#define _reference_H_

void init_preset_0(test_params *params);

#endif
